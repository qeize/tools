//~~~~~~~~~ Setting Owner~~~~~~~~~~//
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6287879307754"] 
global.namabot = 'JUSTIN V20 FASE 2'
//~~~~~~~~~ Setting ~~~~~~~~~~//
global.namach = "Informasi Bot & Website 2025"
global.link = "https://whatsapp.com/channel/0029Vb5BRJmG3R3ZxqFnqX1O"
global.idch = "120363417866318708@newsletter"
global.imgthumb = "https://files.catbox.moe/aw8obb.jpg"
global.vidthumb = "https://files.catbox.moe/x9id78.mp4"
//~~~~~~~~~ Setting Mess ~~~~~~~~~~//
global.mess = { 
owner: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖮𝗐𝗇𝖾𝗋',
premium: '𝖪𝗁𝗎𝗌𝗎𝗌 𝖯𝗋𝖾𝗆𝗂𝗎𝗆',
succes: '𝖲𝗎𝖼𝖼𝖾𝗌𝗌𝖿𝗎𝗅'
//~~~~~~~~~ End ~~~~~~~~~~//
}