# UPDATE
Update 26/08/2023
- Add check tool to check information of website, ip
# Usage
Change :
- discord webhook in line 15
- token bot in line 16
- ipinfo.io API TOKEN in line 171
- ipgeolocation.io API TOKEN in line 287 
- api ddos in line 312
- method l7 in line 621, 720, 729, 
- method l4 in line 633, 656, 664
- admin id in line 912
- change file users.txt to use bot
- Tele: @atusssssssss
- Any questions please DM Telegram
# DEMO FEATURES
![CB543B81-CED0-495A-9C96-246E861DDCFF](https://github.com/vominht/BOT-DDoS-TELEGRAM/assets/103721562/40f8438e-8433-4757-9e7b-34e81624d732)
![A9FC6E66-571A-45A1-A1A4-C42E83E39699](https://github.com/vominht/BOT-DDoS-TELEGRAM/assets/103721562/e8b979ae-1d76-4d34-b3af-296888b636ca)
![F5411F46-055C-4B9F-B444-97B548B92D62](https://github.com/vominht/BOT-DDoS-TELEGRAM/assets/103721562/8f729def-1fa0-4d77-923a-3e6b1ef9deaf)
