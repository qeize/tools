const express = require("express");
const fs = require("fs");
const path = require("path"); // Import modul path

const app = express();
const themePath = '/root/manager/Theme/css'; // Sesuaikan dengan path folder theme Anda
const keysFilePath = path.join(__dirname, "keys.json");

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");
app.set("trust proxy", 1);

console.clear();

setInterval(() => {
    const keyFile = fs.readFileSync(keysFilePath);
    let keyData = JSON.parse(keyFile);

    for (let key in keyData) {
        keyData[key].curCons = 0;
    }

    fs.writeFile(keysFilePath, JSON.stringify(keyData, null, 4), (err) => {
        if (err) {
            console.error(err);
        }
    });
}, 1000); // Setiap 1 detik

const routes = fs.readdirSync("./routes/").filter(f => f.endsWith(".js"));
routes.forEach(file => {
    const route = require(`./routes/${file}`);
    const name = file.substring(0, file.length - 3).toLowerCase();

    try {
        if (name === "index") app.use("/", route);
        app.use(`/${name}`, route);
    } catch (err) {
        console.error(err.stack);
    }

});

app.get('/', (req, res) => {
  // Baca konten dari index.html
  fs.readFile('index.ejs', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).send('Internal Server Error');
    } else {
      // Kirim konten HTML ke EJS sebagai data
      res.render('index.ejs', { htmlContent: data, themePath: themePath });
    }
  });
});

// Login System
app.get("/addkeys", (req, res) => {
    // Tampilkan form untuk menambahkan pengguna
    res.send(`
        <html>
<head>
    <title>Add User Form</title>
    <style>
        body {
            background-color: #151414; /* Latar belakang hitam keabu-abuan */
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #343232;//rgba(169, 169, 169, 0.8); /* Kotak dengan opacity 80% */
            padding: 20px;
            border-radius: 10px;
            opacity: 0.6;
            
        }

        form {
            background-color: #343232; /* Latar belakang abu-abu dalam formulir */
            padding: 20px;
            border-radius: 5px;
            display: flex;
            flex-direction: column;
            opacity: 5;
        }

        label {
            font-weight: bold;
            color: white;
            display: flex;
            flex-direction: column;
            opacity: 1;
        }
        
        labels {
            font-weight: bold;
            font-size: x-large;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 1;
        }

        input {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #777777;
            border-radius: 5px;
            opacity: 1;
        }

        button {
            background-color: #555555;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            opacity: 1;
        }

        button:hover {
            background-color: #444444;
            opacity: 1;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="/addkey" method="GET">
        <labels>Admin Panel</labels><br>
            <label for="key">Key:</label>
            <input type="text" id="key" name="key" required><br><br>

            <label for="time">Time:</label>
            <input type="text" id="time" name="time" required><br><br>

            <label for="maxCons">Max Concurrents:</label>
            <input type="text" id="maxCons" name="maxCons" required><br><br>

            <button type="submit">Add User</button>
        </form>
    </div>
</body>
</html>
    `);
});

app.get("/addkey", (req, res) => {
    const key = req.query.key;
    const time = req.query.time;
    const maxCons = req.query.maxCons;
});


app.get("/addkey", (req, res) => {
    res.render("addkey");
});

app.get("/addkey", (req, res) => {
    const { key, time, maxCons } = req.query;

    if (key && time && maxCons) {
        const keyFile = fs.readFileSync(keysFilePath);
        let keyData = JSON.parse(keyFile);

        if (keyData[key]) {
            return res.send("Key already exists.");
        }

        keyData[key] = {
            time: parseInt(time),
            maxCons: parseInt(maxCons),
            curCons: 0
        };

        fs.writeFile(keysFilePath, JSON.stringify(keyData, null, 4), (err) => {
            if (err) {
                console.error(err);
                return res.status(500).send("Failed to add user.");
            }
        });
    } else {
        res.status(400).send("Invalid request. Make sure to include key, time, and maxCons in the URL query.");
    }
});


app.get("/service-worker.js", (req, res) => {
    res.render("service-worker.js");
});

app.get("/service-worker-iframe-url.html", (req, res) => {
    res.render("service-worker-iframe-url.html");
});

app.get("/methods", (req, res) => {
    res.render("methods");
});

app.listen(80, async () => {
    console.log(`
¦¦¦¦¦¦¦ ¦¦   ¦¦ ¦¦    ¦¦ ¦¦¦    ¦¦ ¦¦¦¦¦¦¦ ¦¦¦¦¦¦¦¦      ¦¦¦¦¦  ¦¦¦¦¦¦  ¦¦ 
¦¦      ¦¦  ¦¦   ¦¦  ¦¦  ¦¦¦¦   ¦¦ ¦¦         ¦¦        ¦¦   ¦¦ ¦¦   ¦¦ ¦¦ 
¦¦¦¦¦¦¦ ¦¦¦¦¦     ¦¦¦¦   ¦¦ ¦¦  ¦¦ ¦¦¦¦¦      ¦¦        ¦¦¦¦¦¦¦ ¦¦¦¦¦¦  ¦¦ 
     ¦¦ ¦¦  ¦¦     ¦¦    ¦¦  ¦¦ ¦¦ ¦¦         ¦¦        ¦¦   ¦¦ ¦¦      ¦¦ 
¦¦¦¦¦¦¦ ¦¦   ¦¦    ¦¦    ¦¦   ¦¦¦¦ ¦¦¦¦¦¦¦    ¦¦        ¦¦   ¦¦ ¦¦      ¦¦ 
`);
    console.log("[Information] API Manager - LizardApis v3");
    console.log("[Information] Successfully Loged in with Username: LizardPredator");
    console.log("[Information] Licensed Role: Developer");
    console.log("[Information] Loaded Api Settings");
    console.log("[Information] Api Settings Loaded!");
    console.log("");
    console.log("[Information] Credit Telegram: t.me/skynetc2");
    console.log("[Information] Expiry: 360 Days Left");
    console.log("");
    console.log("                  LOGS                  ");
});

process.on('uncaughtException', err => console.error(err.stack));
process.on('unhandledRejection', err => console.error(err.stack));